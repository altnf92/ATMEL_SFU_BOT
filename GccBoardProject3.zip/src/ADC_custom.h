﻿/*
 * ADC_custom.h
 *
 * Created: 2020-03-23 오후 6:44:15
 *  Author: khs
 */ 
